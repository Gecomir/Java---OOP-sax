package hero;

public class Main {
    public static void main(String[] args) {


        BladeKnight bladeKnight = new BladeKnight("Gecomir", 99);
        System.out.println(bladeKnight);
    }
}