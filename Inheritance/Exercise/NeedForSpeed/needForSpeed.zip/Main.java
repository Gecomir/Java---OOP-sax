package Inheritance.needForSpeed;

public class Main {
}
