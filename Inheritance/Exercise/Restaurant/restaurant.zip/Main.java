package Inheritance.restaurant;

public class Main {
}
