package WildFarm;

public class Messages {
    public static final String MOUSE_SOUND = "SQUEEEAAAK!";
    public static final String CAT_SOUND = "Meowwww";
    public static final String TIGER_SOUND = "ROAAR!!!";
    public static final String ZEBRA_SOUND = "Zs";
    public static final String WRONG_FOOD = "%s are not eating that type of food!";
}
