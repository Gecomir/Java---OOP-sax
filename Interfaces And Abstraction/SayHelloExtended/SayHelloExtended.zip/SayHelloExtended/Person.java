package SayHelloExtended;

public interface Person {

    String getName();
    String sayHello();
}
