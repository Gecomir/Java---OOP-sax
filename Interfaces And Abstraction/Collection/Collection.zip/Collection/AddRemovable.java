package Collection;

public interface AddRemovable extends Addable{
    String remove();
}
