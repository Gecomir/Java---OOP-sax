package Collection;

public interface MyList extends AddRemovable{
    int getUsed();
}
