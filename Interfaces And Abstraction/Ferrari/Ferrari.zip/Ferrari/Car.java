package Ferrari;

public interface Car {

    String brakes();
    String gas();

}
