package football.entities.supplement;

public class Powdered extends BaseSupplement{

    private static int energy = 120;
    private static double price = 15;

    public Powdered() {
        super(energy, price);
    }
}
