package football.entities.supplement;

public class Liquid extends BaseSupplement{

    private static int energy = 90;
    private static double price = 25;

    public Liquid() {
        super(energy, price);
    }
}
