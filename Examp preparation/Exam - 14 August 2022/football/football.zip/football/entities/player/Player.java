package football.entities.player;

public interface Player {
    void setName(String name);

    int stimulation();

    double getKg();

    String getName();

    int getStrength();


}
