package football.core;

public interface Engine extends Runnable {
}
