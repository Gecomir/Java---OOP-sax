package CounterStriker.common;

public class Constants {
    public final static int PISTOL_BULLETS_PER_SHOOT = 1;

    public final static int RIFLE_BULLETS_PER_SHOOT = 10;
}
