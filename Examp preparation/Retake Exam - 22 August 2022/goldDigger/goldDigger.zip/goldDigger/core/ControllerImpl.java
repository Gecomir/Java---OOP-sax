package goldDigger.core;

import goldDigger.models.discoverer.Anthropologist;
import goldDigger.models.discoverer.Archaeologist;
import goldDigger.models.discoverer.Discoverer;
import goldDigger.models.discoverer.Geologist;
import goldDigger.models.operation.Operation;
import goldDigger.models.operation.OperationImpl;
import goldDigger.models.spot.Spot;
import goldDigger.models.spot.SpotImpl;
import goldDigger.repositories.DiscovererRepository;
import goldDigger.repositories.SpotRepository;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static goldDigger.common.ConstantMessages.*;
import static goldDigger.common.ExceptionMessages.*;

public class ControllerImpl implements Controller{
    private final DiscovererRepository discovererRepository;
    private final SpotRepository spotRepository;
    private int countSpots;

    public ControllerImpl() {
        this.discovererRepository = new DiscovererRepository();
        this.spotRepository = new SpotRepository();
        countSpots = 0;
    }

    @Override
    public String addDiscoverer(String kind, String discovererName) {
        Discoverer discoverer;
        switch (kind) {
            case "Anthropologist":
                discoverer = new Anthropologist(discovererName);
                break;
            case "Archaeologist":
                discoverer = new Archaeologist(discovererName);
                break;
            case "Geologist":
                discoverer = new Geologist(discovererName);
                break;
            default:
                throw new IllegalArgumentException(DISCOVERER_INVALID_KIND);
        }

        discovererRepository.add(discoverer);
        return String.format(DISCOVERER_ADDED, kind, discovererName);
    }

    @Override
    public String addSpot(String spotName, String... exhibits) {
        Spot spot = new SpotImpl(spotName);
        Collections.addAll(spot.getExhibits(), exhibits);
        spotRepository.add(spot);
        return String.format(SPOT_ADDED, spotName);
    }

    @Override
    public String excludeDiscoverer(String discovererName) {
        Discoverer discovererToRemove = (Discoverer) discovererRepository.byName(discovererName);
        if (discovererToRemove == null) {
            throw new IllegalArgumentException(String.format(DISCOVERER_DOES_NOT_EXIST, discovererName));
        }
        discovererRepository.remove(discovererToRemove);
        return String.format(DISCOVERER_EXCLUDE, discovererName);
    }

    @Override
    public String inspectSpot(String spotName) {
        //Само изследователи със сила > 45
        List<Discoverer> validDiscoverers = discovererRepository
                .getCollection()
                .stream()
                .filter(e -> e.getEnergy() > 45)
                .collect(Collectors.toList());

        //Ако няма никой -> exception
        if (validDiscoverers.isEmpty()) {
            throw new IllegalArgumentException(SPOT_DISCOVERERS_DOES_NOT_EXISTS);
        }
        //Стартираме експедицията
        Spot spotToExplore = (Spot) spotRepository.byName(spotName);
        Operation operation = new OperationImpl();
        operation.startOperation(spotToExplore, validDiscoverers);
        //Брой изследователи със сила = 0
        long countOfExcludedDiscoverers = validDiscoverers.stream().filter(e -> e.getEnergy() == 0).count();
        countSpots++;
        return String.format(INSPECT_SPOT, spotName, countOfExcludedDiscoverers);
    }

    @Override
    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(FINAL_SPOT_INSPECT, countSpots));
        sb.append(System.lineSeparator());
        sb.append(FINAL_DISCOVERER_INFO);
        sb.append(System.lineSeparator());
        discovererRepository.getCollection().forEach((discoverer) -> {
            sb.append(String.format(FINAL_DISCOVERER_NAME, discoverer.getName()));
            sb.append(System.lineSeparator());
            sb.append(String.format(FINAL_DISCOVERER_ENERGY, discoverer.getEnergy()));
            sb.append(System.lineSeparator());

            String museumInput = discoverer.getMuseum().getExhibits().isEmpty() ? "None" :
                    discoverer.getMuseum().getExhibits().stream()
                            .map(String::valueOf)
                            .collect(Collectors.joining(FINAL_DISCOVERER_MUSEUM_EXHIBITS_DELIMITER));

            sb.append(String.format(FINAL_DISCOVERER_MUSEUM_EXHIBITS, museumInput));
            sb.append(System.lineSeparator());

        });
        return sb.toString().trim();
    }
}
